from digpdf import main

main()
