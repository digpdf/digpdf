"""digpdf: a PDF written as HTML for an agent to read.

    import digpdf
    html = digpdf.html("report.pdf")                       # the pages, as one HTML document
    png = digpdf.image("report.pdf", 3)                     # page 3 as it is shown, as PNG bytes
    png = digpdf.image("report.pdf", 3, "120,40,880,300")   # the piece of page 3 in a box, as data-bbox gives it

The same as the command line, which the package installs as `digpdf`:

    digpdf report.pdf > report.pdf.html
    digpdf report.pdf 3 > page-3.png
    digpdf report.pdf 3 120,40,880,300 > piece.png

Both run the digpdf program that comes with the package. A file that cannot be read raises Unreadable, with what
digpdf says of it; what it says of a page it writes as one region is passed on to stderr, where there is one.
"""
import os
import subprocess
import sys

__all__ = ["html", "image", "Unreadable"]


class Unreadable(Exception):
    """A file digpdf cannot read, a page or a box it cannot draw: what digpdf says of it."""


def _program():
    here = os.path.dirname(os.path.abspath(__file__))
    program = os.path.join(here, "bin", "digpdf.exe" if os.name == "nt" else "digpdf")
    # an installer that drops the executable bit leaves the program as a file only
    if os.name != "nt" and not os.access(program, os.X_OK):
        try:
            os.chmod(program, os.stat(program).st_mode | 0o111)
        except OSError:
            pass
    return program


def _run(args):
    program = _program()
    # the program named to the system by its path, not found again in the command line: on Windows a path longer
    # than 260 characters is one only so
    r = subprocess.run([program] + [os.fspath(a) for a in args], executable=program, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    said = r.stderr.decode("utf-8", "replace")
    if r.returncode != 0:
        raise Unreadable(said.strip() or "digpdf ended with %d" % r.returncode)
    if said and sys.stderr is not None:
        # a remark is passed on where it can be: a program without a stderr (a window, a service) still gets its page
        try:
            sys.stderr.write(said)
        except Exception:
            pass
    return r.stdout


def html(path):
    """The pages of the PDF at path as one HTML document (str)."""
    return _run([path]).decode("utf-8")


def image(path, page, box=None):
    """Page `page` (as data-page gives it, from 1) of the PDF at path as it is shown, or the piece of it in box (a
    data-bbox as it stands, "x0,y0,x1,y1", or four numbers), as PNG bytes."""
    args = [path, str(int(page))]
    if box is not None:
        args.append(box if isinstance(box, str) else ",".join(str(int(v)) for v in box))
    return _run(args)


def main():
    """The command line: the digpdf program with this command's arguments, its output and exit code as they are."""
    program = _program()
    if os.name == "nt":
        sys.exit(subprocess.call([program] + sys.argv[1:], executable=program))
    os.execv(program, [program] + sys.argv[1:])
