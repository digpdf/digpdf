// digpdf in WebAssembly: a PDF read and written as HTML for an agent to read, in a browser, a Web Worker or Node.
//
//     import { load } from "./digpdf.mjs";
//     const digpdf = await load();                      // digpdf.wasm, pdfium.wasm and pdfium.js beside this file
//     const { html, notes } = await digpdf.html(bytes, "report.pdf");
//     const png = await digpdf.image(bytes, 3, "120,40,880,300", "report.pdf");
//
// The same reading as the program: the same HTML, byte for byte, and the same notes the program writes on stderr
// (without its »digpdf: «). A file that cannot be read at all fails with the program's reason (DigpdfError).
// The work is done in the calling thread: in a browser, call it from a Web Worker.

const DIGPDF_BASE = 4 * 2 ** 20;

/** A file that cannot be read, or a page that cannot be drawn: the program's reason. */
export class DigpdfError extends Error {
  constructor(message) {
    super(message);
    this.name = "DigpdfError";
  }
}

const inNode = typeof process === "object" && typeof process.versions?.node === "string";

async function beside(name) {
  const url = new URL(name, import.meta.url);
  if (inNode && url.protocol === "file:") {
    const fs = await import("node:fs/promises");
    return new Uint8Array(await fs.readFile(url));
  }
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${url}: ${r.status} ${r.statusText}`);
  return new Uint8Array(await r.arrayBuffer());
}

function uleb(b, at) {
  let v = 0, shift = 0, x;
  do {
    x = b[at++];
    v += (x & 0x7f) * 2 ** shift;
    shift += 7;
  } while (x & 0x80);
  return [v, at];
}

function heapBase(b) {
  let at = 8, exported = -1, inits = [];
  while (at < b.length) {
    const id = b[at];
    let size;
    [size, at] = uleb(b, at + 1);
    const end = at + size;
    let p = at, n;
    if (id === 6) {
      [n, p] = uleb(b, p);
      for (let i = 0; i < n; i++) {
        p += 2;
        if (b[p] !== 0x41) throw new Error("digpdf.wasm: a global not set by i32.const");
        let v = 0, shift = 0, x;
        p++;
        do { x = b[p++]; v |= (x & 0x7f) << shift; shift += 7; } while (x & 0x80);
        inits.push(v);
        p++;
      }
    } else if (id === 7) {
      [n, p] = uleb(b, p);
      for (let i = 0; i < n; i++) {
        let len;
        [len, p] = uleb(b, p);
        const name = new TextDecoder().decode(b.subarray(p, p + len));
        p += len;
        const kind = b[p++];
        let index;
        [index, p] = uleb(b, p);
        if (kind === 3 && name === "__heap_base") exported = index;
      }
    }
    at = end;
  }
  if (exported < 0 || exported >= inits.length) throw new Error("digpdf.wasm exports no __heap_base");
  return inits[exported];
}

/**
 * digpdf, ready to read: the three files from beside this module, or as given - each as bytes (an ArrayBuffer or a
 * Uint8Array), and pdfium.js also as its text.
 */
export async function load(given = {}) {
  const [digpdfBytes, pdfiumBytes, pdfiumJs] = await Promise.all([
    given.digpdf ?? beside("digpdf.wasm"),
    given.pdfium ?? beside("pdfium.wasm"),
    given.pdfiumJs ?? beside("pdfium.js"),
  ]);
  const asBytes = (b) => (b instanceof Uint8Array ? b : new Uint8Array(b));
  const js = typeof pdfiumJs === "string" ? pdfiumJs : new TextDecoder().decode(asBytes(pdfiumJs));
  const end = heapBase(asBytes(digpdfBytes));
  const [digpdf, pdfium] = await Promise.all([WebAssembly.compile(asBytes(digpdfBytes)), WebAssembly.compile(asBytes(pdfiumBytes))]);
  const needed = WebAssembly.Module.imports(digpdf).filter((i) => i.module === "pdfium").map((i) => i.name);
  const glue = new Function("Module", "process", js + "\nreturn Module;");

  function pdfiumInstance() {
    let ex, ready = false, aborted;
    glue({
      instantiateWasm(imports, receive) {
        const inst = new WebAssembly.Instance(pdfium, imports);
        ex = inst.exports;
        receive(inst, pdfium);
        return inst.exports;
      },
      onRuntimeInitialized() { ready = true; },
      onAbort(what) { aborted = what; },
      print() {},
      printErr() {},
    }, undefined);
    if (!ready) throw new Error(`pdfium did not start${aborted ? ": " + aborted : ""}`);
    return ex;
  }

  function pair() {
    const pex = pdfiumInstance();
    const block = pex.malloc(end);
    if (!block || block > DIGPDF_BASE) throw new Error("not enough memory for digpdf");
    const p = { pex, mem: pex.memory, said: null, drawer: null, drawn: null };
    const env = {
      memory: pex.memory,
      pdfium_malloc: pex.malloc,
      pdfium_free: pex.free,
      random_fill: (at, n) => { crypto.getRandomValues(new Uint8Array(p.mem.buffer, at, n)); },
      failed: (at, n) => { p.said = new TextDecoder().decode(new Uint8Array(p.mem.buffer, at, n).slice()); },
      draw_apart: (dp, dl, mp, ml) => drawApart(p, dp, dl, mp, ml),
    };
    const imports = {};
    for (const name of needed) imports[name] = pex[name];
    p.d = new WebAssembly.Instance(digpdf, { env, pdfium: imports }).exports;
    return p;
  }

  const view = (p) => new Uint8Array(p.mem.buffer);

  function put(p, bytes) {
    const at = bytes.length ? p.pex.malloc(bytes.length) : 0;
    if (bytes.length) view(p).set(bytes, at);
    return at;
  }

  function reply(p, at) {
    const word = new DataView(p.mem.buffer).getUint32(at, true);
    const bytes = view(p).slice(at + 4, at + 4 + (word & 0x7fffffff));
    p.d.digpdf_free(at);
    return { failed: (word & 0x80000000) !== 0, bytes };
  }

  function boxed(p, bytes, failed) {
    const raw = p.pex.malloc(bytes.length + 4 + 8), at = (raw + 4 + 7) & ~7;
    const dv = new DataView(p.mem.buffer);
    dv.setUint32(at - 4, at - raw, true);
    dv.setUint32(at, bytes.length | (failed ? 0x80000000 : 0), true);
    view(p).set(bytes, at + 4);
    return at;
  }

  function guarded(p, f) {
    p.said = null;
    try {
      return { value: f() };
    } catch (e) {
      if (!(e instanceof WebAssembly.RuntimeError) && !(e instanceof RangeError)) throw e;
      return { ended: p.said, trap: String(e && e.message || e) };
    }
  }

  function drawApart(main, dp, dl, mp, ml) {
    const msg = view(main).slice(mp, mp + ml);
    if (!main.drawer || main.drawn?.from !== dp || main.drawn?.len !== dl) {
      if (!main.drawer) main.drawer = pair();
      if (main.drawn) main.drawer.pex.free(main.drawn.at);
      main.drawn = { from: dp, len: dl, at: put(main.drawer, view(main).subarray(dp, dp + dl)) };
    }
    const b = main.drawer, bm = put(b, msg);
    const got = guarded(b, () => reply(b, b.d.digpdf_draw(main.drawn.at, dl, bm, ml)));
    if (got.value) {
      b.pex.free(bm);
      return boxed(main, got.value.bytes, false);
    }
    main.drawer = null;
    main.drawn = null;
    return boxed(main, new TextEncoder().encode(got.ended ?? "the copy of the process ended without a result"), true);
  }

  function opened(pdf, name) {
    const p = pair();
    const at = put(p, pdf), nm = new TextEncoder().encode(name), nat = put(p, nm);
    const r = reply(p, p.d.digpdf_open(at, pdf.length, nat, nm.length));
    p.pex.free(at);
    if (nat) p.pex.free(nat);
    if (r.failed) throw new DigpdfError(new TextDecoder().decode(r.bytes));
    return { p, pages: new DataView(r.bytes.buffer).getUint32(0, true) };
  }

  const bytesOf = (pdf) => (pdf instanceof Uint8Array ? pdf : new Uint8Array(pdf));

  return {
    /**
     * The PDF's bytes read and written as HTML: {html, notes}, notes what the program writes on stderr, a note
     * for each thing it says (a damaged file read as pdfium repairs it, a page that could not be read), without its
     * »digpdf: «. name is what the notes call the file.
     */
    async html(pdf, name = "document.pdf") {
      pdf = bytesOf(pdf);
      let { p, pages } = opened(pdf, name);
      const read = [];
      for (let pno = 0; pno < pages; pno++) {
        let got = guarded(p, () => reply(p, p.d.digpdf_page(pno)));
        const failed = got.value ? null : got.ended;
        for (const bare of [0, 1]) {
          if (got.value) break;
          if (got.ended === null) throw new DigpdfError(`${name} p${pno + 1} could not be read, and the reading ended: ${got.trap}`);
          const said = new TextEncoder().encode(failed);
          ({ p } = opened(pdf, name));
          const at = put(p, said);
          got = guarded(p, () => reply(p, p.d.digpdf_unread(pno, at, said.length, bare)));
        }
        if (!got.value) throw new DigpdfError(`${name} p${pno + 1} could not be read, and the reading ended: ${got.ended ?? got.trap}`);
        read.push(got.value.bytes);
      }
      const all = new Uint8Array(read.reduce((n, b) => n + b.length, 0));
      read.reduce((at, b) => (all.set(b, at), at + b.length), 0);
      const at = put(p, all);
      const r = reply(p, p.d.digpdf_document(at, all.length));
      const n = new DataView(r.bytes.buffer).getUint32(0, true);
      const text = new TextDecoder();
      const notes = n ? text.decode(r.bytes.subarray(4, 4 + n)).split("\0") : [];
      return { html: text.decode(r.bytes.subarray(4 + n)), notes };
    },

    /**
     * Page n (from 1, as data-page counts) of the PDF as it is shown, or the piece of it in box (data-bbox's text,
     * »120,40,880,300«), as PNG bytes.
     */
    async image(pdf, n, box = null, name = "document.pdf") {
      pdf = bytesOf(pdf);
      const p = pair();
      const enc = new TextEncoder(), nm = enc.encode(name), bx = enc.encode(box ?? "");
      const at = put(p, pdf), nat = put(p, nm), bat = put(p, bx);
      const r = reply(p, p.d.digpdf_image(at, pdf.length, nat, nm.length, BigInt(n), bat, bx.length));
      if (r.failed) throw new DigpdfError(new TextDecoder().decode(r.bytes));
      return r.bytes;
    },
  };
}
