#!/usr/bin/env node
// digpdf, the command, as the program is:
//
//     npx digpdf FILE.pdf > FILE.pdf.html                    the pages
//     npx digpdf FILE.pdf 3 > page-3.png                      page 3 as it is shown
//     npx digpdf FILE.pdf 3 120,40,880,300 > piece.png        the piece of page 3 in a box, as data-bbox gives it

import { load, DigpdfError } from "./digpdf.mjs";
import { readFile } from "node:fs/promises";

const usage = "usage: digpdf FILE.pdf [PAGE [X0,Y0,X1,Y1]]";

/** The system's own words for why a file cannot be opened. */
const reasons = {
  ENOENT: "No such file or directory",
  EACCES: "Permission denied",
  EISDIR: "Is a directory",
  ENOTDIR: "Not a directory",
  ELOOP: "Too many levels of symbolic links",
  ENAMETOOLONG: "File name too long",
  EMFILE: "Too many open files",
  EPERM: "Operation not permitted",
};

function fail(message, code = 1) {
  process.stderr.write(`digpdf: ${message}\n`);
  process.exit(code);
}

function written(bytes) {
  process.stdout.on("error", (e) => {
    if (e.code !== "EPIPE") process.stderr.write(`digpdf: the output cannot be written: ${reasons[e.code] ?? e.message}\n`);
    process.exit(1);
  });
  process.stdout.write(bytes);
}

const args = process.argv.slice(2);
if (args.length < 1 || args.length > 3) {
  process.stderr.write(usage + "\n");
  process.exit(2);
}
const [path, page, box] = args;
let n = null;
if (args.length > 1) {
  const t = page.trim();
  n = /^[+-]?\d+$/.test(t) ? BigInt(t) : null;
  if (n === null || n < -(2n ** 63n) || n >= 2n ** 63n) {
    process.stderr.write(`${usage} - the page is its number, from 1\n`);
    process.exit(1);
  }
}
let pdf;
try {
  pdf = await readFile(path);
} catch (e) {
  fail(`${path} cannot be opened: ${reasons[e.code] ?? e.message}`);
}
try {
  const digpdf = await load();
  if (n === null) {
    const { html, notes } = await digpdf.html(pdf, path);
    for (const note of notes) process.stderr.write(`digpdf: ${note}\n`);
    written(html);
  } else {
    written(await digpdf.image(pdf, n, box ?? null, path));
  }
} catch (e) {
  if (e instanceof DigpdfError) fail(e.message);
  throw e;
}
